﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace BankAccount
{
    public class BackAccount
    {
        public double Balance { set; get; }
        public void Deposit(double amount)
        {
            Balance = Balance + (amount * 0.25/100) ;
            Write("\n\n" + Balance + "\n\n");
        }
        public void Withdraw(double withdraw)
        {
            WriteLine("Enter the amount you want to withdraw:\n\n");
            withdraw = Read();
            if(withdraw > Balance)
            {
                Balance = Balance - withdraw * 0.5;
                Write("Your remaining balance is: \n\n " + Balance);             
            }
        }
        public void CheckBalance(double Balance)
        {
            WriteLine("Enter 1 to check balance:");
            int key = Read();
            if(key == 1)
            {
                WriteLine("Your Account Balance is: \n\n" + Balance);
            }
            else
            {
                WriteLine("You entered the wrong key");
            }
        }
    }
}
