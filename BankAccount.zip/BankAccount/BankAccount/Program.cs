﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace BankAccount
{
    class Program
    {
        static void Main(string[] args)
        {
            BackAccount Transactions = new BackAccount();
                 
            Write("For Deposit Press : 1\nFor Balance Press : 2\nFor Withdrawing Press : 3 \n");
            string key = Console.ReadLine();

            if( key.Contains("1") )
            {
                //Deposit
                WriteLine("Enter the amount you're depositing:");
                double val = Double.Parse(ReadLine().ToString());
                Transactions.Deposit(val);
                ReadLine();
            }
            else if(key.Contains("2") )
            {
                //Check balance
                Transactions.CheckBalance(200);
                ReadLine();
            }
            else if(key.Contains("3") )
            {
                //Withdraw
                Transactions.Withdraw(344);
                ReadLine();
            }
            else
            {
                Write("Wrog key entered"); 
            }

            Console.Read();
        }
    }
}
