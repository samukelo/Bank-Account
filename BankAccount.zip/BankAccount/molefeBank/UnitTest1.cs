﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using molefeBank;
namespace molefeBank
{
    [TestClass]
    public class UnitTest1 
    {
        [TestMethod]
        public void amountneeded()
        {
           
        }
      
    }
}
